package Test_Cases;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;
import javafx.beans.property.SetProperty;


public class T_01_Login_Test_Case extends T_00_TestBase {


	@Test
	public void Invalid_Username() throws IOException {
		P_01_Login_Page p01 = new P_01_Login_Page(driver);

		// Enter invalid username
		p01.username_txt().sendKeys("username");

		// Enter invalid Password
		p01.password_txt().sendKeys("password");

		// click login button
		p01.Login_Btn().click();
		System.out.println(p01.flash_message().getText());
		setProperty("Text",p01.flash_message().getText());
		// assertion error message
		assertTrue(p01.flash_message().getText().contains("Your username is invalid"));
	}

	@Test
	public void valid_username() throws InterruptedException, IOException {
		P_01_Login_Page p01 = new P_01_Login_Page(driver);

		// Clear Username Field
		p01.username_txt().clear();

		// Enter valid username
		p01.username_txt().sendKeys("tomsmith");

		// Clear Password Field
		p01.password_txt().clear(); 

		// Enter valid password
		p01.password_txt().sendKeys("SuperSecretPassword!");

		// Press Submit
		p01.password_txt().submit();
		Thread.sleep(2000);
		System.out.println(p01.flash_Msg().getText());
		//setProperty("Text", p01.flash_message().getText());
		// Verify success message
		assertTrue(p01.flash_Msg().getText().contains("You logged into a secure area"));

	}



}
