package Open_Browser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Chrome_Browser {
	public static void main (String[] args) {
		
		String chromePath = (System.getProperty("user.dir") + "\\Browsers\\chromedriver.exe");
	
		System.setProperty("webdriver.chrome.driver",chromePath);
		WebDriver driver= new ChromeDriver ();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.google.com/");
		driver.quit();
	}
	
}