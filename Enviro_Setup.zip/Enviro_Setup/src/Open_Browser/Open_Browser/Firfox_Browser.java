package Open_Browser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Firfox_Browser {
	public static void main (String[] args) {
		
		String firefoxPath = (System.getProperty("user.dir") + "\\Browsers\\geckodriver.exe");
	
		System.setProperty("webdriver.gecko.driver",firefoxPath);
		System.setProperty("webdriver.firefox.bin", "C:\\Program Files\\Mozilla Firefox\\firefox.exe");
		
		WebDriver driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.google.com/");
		driver.quit();
	}
	
}