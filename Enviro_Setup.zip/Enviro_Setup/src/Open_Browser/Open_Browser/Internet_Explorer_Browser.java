package Open_Browser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;



public class Internet_Explorer_Browser {

public static void main(String[] args) {



String iePath = System.getProperty("user.dir") + "\\Browsers\\IEDriverServer.exe";

System.setProperty("webdriver.ie.driver", iePath);
DesiredCapabilities cap = new DesiredCapabilities();
cap.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true); 
cap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);

WebDriver driver = new InternetExplorerDriver(cap);

driver.manage().window().maximize();

driver.navigate().to("https://www.google.com/");

driver.quit();

}

}
