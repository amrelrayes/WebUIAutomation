package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_1_Main;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import org.testng.annotations.Test;

import javafx.beans.property.SetProperty;
import org.testng.TestNGException;



public class T_01_Social_Media extends T_0_TestBase {

	@Test
	public void Social_Media () throws IOException, Exception   {
		P_1_Main p01 = new P_1_Main(driver);
		p01.Login().click();
		Thread.sleep(2000);
		p01.Email().sendKeys(prop.getProperty("Email"));

		p01.Password().sendKeys(prop.getProperty("Password"));
		p01.Login_Btn().click();
		p01.Facebook().click();
		Thread.sleep(2000);
		Set<String> WindowHandle = driver.getWindowHandles();
		ArrayList<String> Tabs = new ArrayList<>(WindowHandle);
		
		driver.switchTo().window(Tabs.get(1));
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		System.out.println(driver.getWindowHandle());

		driver.switchTo().window(Tabs.get(0));
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
		System.out.println(driver.getWindowHandle());

	}
}
