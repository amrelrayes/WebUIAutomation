package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P_1_Main extends P_0_PageBase {

	public P_1_Main (WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public WebElement Login(){
  	   return driver.findElement(By.xpath("//a[@class=\"ico-login\"]"));
     }
	public WebElement Email(){
	  	   return driver.findElement(By.xpath("//input[@class=\"email\"]"));
	     }
	public WebElement Password(){
	  	   return driver.findElement(By.xpath("//input[@class=\"password\"]"));
	     }
	public WebElement Login_Btn(){
	  	   return driver.findElement(By.xpath("//input[@class=\"button-1 login-button\"]"));
	     }
	public WebElement Facebook(){
	  	   return driver.findElement(By.xpath("//a[@href=\"http://www.facebook.com/nopCommerce\"]"));
	     }
}	
	
