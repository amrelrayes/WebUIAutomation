package Pack_00_PageBase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class P_00_PageBase {
	protected WebDriver driver;
	
	public P_00_PageBase(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
