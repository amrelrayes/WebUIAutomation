package Pack_04_Home_Page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Pack_00_PageBase.P_00_PageBase;

public class P_01_Home extends P_00_PageBase{

	public P_01_Home(WebDriver driver) {
		super(driver);
	}

	public WebElement El_00_LogOut ()
	{	
	return driver.findElement(By.xpath("//a[@href=\"/logout\"]"));
	}
		
	public WebElement  El_01_Currency (String currency)
	{	
	return driver.findElement(By.xpath("//option[contains(text(),\""+currency+"\")]"));
	}

	public List<WebElement> El_10_top_menus (String num)
	{	
	return driver.findElements(By.xpath("(//ul[@class=\"top-menu notmobile\"]/li/a)"+num));

	}	

	
	public List<WebElement> El_20_actual_prices (String num)
	{	
	return driver.findElements(By.xpath("(//span[@class=\"price actual-price\"])"+num));

	}	
}
