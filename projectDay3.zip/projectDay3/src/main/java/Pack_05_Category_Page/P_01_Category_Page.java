package Pack_05_Category_Page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Pack_00_PageBase.P_00_PageBase;

public class P_01_Category_Page extends P_00_PageBase{

	public P_01_Category_Page(WebDriver driver) {
		super(driver);
	}

	public WebElement El_01_bar_notification ()
	{	
	return driver.findElement(By.xpath("//div[@id=\"bar-notification\"]//*[@class=\"content\"]"));
	}	
	
	public WebElement El_02_bar_notification_success ()
	{	
	return driver.findElement(By.xpath("//div[@class=\"bar-notification success\"]/p"));
	}

	public List<WebElement> El_10_sub_category (String num)
	{	
	return driver.findElements(By.xpath("//div[@class=\"sub-category-item\"]/h2[@class=\"title\"]/a"+num));
	}
	
	public WebElement El_27_product_title (int num)
	{	
	return driver.findElement(By.xpath("(//h2[@class=\"product-title\"])["+num+"]/a"));
	}
	
	public List<WebElement> El_30_Add_To_Cart ()
	{	
	return driver.findElements(By.xpath("//input[@value=\"Add to cart\"]"));
	}

	
	
}
