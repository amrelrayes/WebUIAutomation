package Pack_01_Registration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Pack_00_PageBase.P_00_PageBase;

public class P_01_register extends P_00_PageBase{

	public P_01_register(WebDriver driver) {
		super(driver);
	}

	//@FindBy(xpath = "//div[contains(text(),\"Your registration completed\")]")
	//List<WebElement> El_08_successMsg;
	
	public WebElement  El_00_registerLink ()
	{	
	return driver.findElement(By.xpath("//a[@href=\"/register?returnUrl=%2F\"]"));
	}
	
	public WebElement El_01_genderMale ()
	{
	return driver.findElement(By.id("gender-male"));
	}

	public WebElement El_01_genderFemale ()
	{
		return driver.findElement(By.id("gender-female"));

	}
	
	public WebElement El_02_FirstName ()
	{
		return driver.findElement(By.id("FirstName"));

	}
	
	public WebElement El_03_LastName ()
	{
		return driver.findElement(By.id("LastName"));
	}
	
	public WebElement El_04_DateOfBirthDay ()
	{
		return driver.findElement(By.name("DateOfBirthDay"));
	}
	
	public WebElement El_04_DateOfBirthMonth ()
	{
		return driver.findElement(By.name("DateOfBirthMonth"));
	}
	
	public WebElement El_04_DateOfBirthYear ()
	{
		return driver.findElement(By.name("DateOfBirthYear"));
	}
	
	public WebElement El_05_Email ()
	{
		return driver.findElement(By.id("Email"));
	}
	
	public WebElement El_06_Password ()
	{
		return driver.findElement(By.id("Password"));
	}
	
	public WebElement El_06_ConfirmPassword ()
	{
		return driver.findElement(By.id("ConfirmPassword"));
	}
	
	public WebElement El_07_registerBtn ()
	{
		return driver.findElement(By.id("register-button"));
	}
	
	public List<WebElement> El_08_successMsg ()
	{
	return driver.findElements(By.xpath("//div[contains(text(),\"Your registration completed\")]"));
	}
	
	public List<WebElement> El_09_existMsg ()
	{
	return driver.findElements(By.xpath("//li[contains(text(),\"The specified email already exists\")]"));
	}
	
}
