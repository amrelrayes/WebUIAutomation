package Pack_02_SignIn;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Pack_00_PageBase.P_00_PageBase;
import Pack_01_Registration.P_01_register;

public class P_01_SignIn extends P_00_PageBase {
	public P_01_SignIn(WebDriver driver) {
		super(driver);
	}
	
	public WebElement  El_00_Login_Tab ()
	{	
	return driver.findElement(By.xpath("//a[@href=\"/login?returnUrl=%2F\"]"));	
	}

	public WebElement  El_10_Login ()
	{	
	return driver.findElement(By.xpath("//input[@value=\"Log in\"]"));
	}
	
	public void Login_With_User(String Email, String Password)
	{
		El_00_Login_Tab().click();	  
		P_01_register register = new P_01_register(driver);
		register.El_05_Email().sendKeys(Email);
		register.El_06_Password().sendKeys(Password);
		El_10_Login().click();
	}
	
}
