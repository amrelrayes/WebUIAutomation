package Tests_00_TestBase;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class T_01_Properties_File {


	public String getPropertydata( String KeyName) throws IOException
	{
	Properties prop = new Properties();
	FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\data.properties");
	prop.load(fis);
	return	prop.getProperty(KeyName);
	}
	
	public void setPropertydata( String KeyName, String Value) throws IOException
	{
	Properties prop = new Properties();
	FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\data.properties");
	prop.load(fis);
	prop.setProperty(KeyName, Value);
	FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+"\\data.properties");
	prop.store(fos, "TestComment");
	}

}
