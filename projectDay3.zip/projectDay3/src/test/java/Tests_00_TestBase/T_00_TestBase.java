package Tests_00_TestBase;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.github.bonigarcia.wdm.WebDriverManager;

public class T_00_TestBase{
	
	protected WebDriver driver;
	protected T_01_Properties_File Proper= new T_01_Properties_File();
	
  @BeforeClass
  public void LaunchBrowser() throws IOException, InterruptedException {

	  if(Proper.getPropertydata("browserName").equalsIgnoreCase("chrome"))
	  {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
	  }
	  else if(Proper.getPropertydata("browserName").equalsIgnoreCase("firefox"))
	  {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver(); 
	  }
		driver.manage().window().maximize();
		driver.get("https://demo.nopcommerce.com");
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
  }


  @AfterClass
  public void CloseBrowser() {
		driver.quit();		
  }

}
