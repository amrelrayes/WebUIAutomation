package Tests_04_Add_To_Cart;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.Random;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;

import Pack_02_SignIn.P_01_SignIn;
import Pack_04_Home_Page.P_01_Home;
import Pack_05_Category_Page.P_01_Category_Page;
import Tests_00_TestBase.T_00_TestBase;

public class T_01_Add_Carts extends T_00_TestBase{

	Select select;
	P_01_Home home;
	P_01_Category_Page Category;
	P_01_SignIn SignIn; 
	WebDriverWait wait;

	
	public void Initialize() 
	{
		  home = new P_01_Home(driver);
		  wait = new WebDriverWait(driver, 10);
		  Category = new P_01_Category_Page(driver);
		  SignIn = new P_01_SignIn(driver);
	}
	
  @Test
  public void Add_Carts() throws IOException, InterruptedException {
	
	Initialize();
	
	driver.get("https://demo.nopcommerce.com/");
	SignIn.Login_With_User(Proper.getPropertydata("Email"), Proper.getPropertydata("Password"));
	
	int menus = new Random().nextInt(home.El_10_top_menus("").size());
	home.El_10_top_menus("").get(menus).click();
	Reporter.log(home.El_10_top_menus("").get(menus).getText());
	
	if(!Category.El_10_sub_category("").isEmpty())
	  {
	
	int sub_menus = new Random().nextInt(Category.El_10_sub_category("").size());
	
	Reporter.log(Category.El_10_sub_category("").get(sub_menus).getText());
	
	Category.El_10_sub_category("").get(sub_menus).click();
	
	  }
	
	int product = new Random().nextInt(Category.El_30_Add_To_Cart().size());
	Reporter.log(Category.El_27_product_title(product+1).getText());
	Category.El_30_Add_To_Cart().get(product).click();
	
	String success_msg= wait.until(ExpectedConditions.visibilityOf(Category.El_01_bar_notification())).getText();
	Reporter.log(success_msg);
	assertTrue(success_msg.contains("The product has been added to your"));


 }
  
 }