package Tests_01_Registration;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.Random;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Pack_01_Registration.P_01_register;
import Tests_00_TestBase.T_00_TestBase;

public class T_01_Register_Valid_User extends T_00_TestBase{

	Select select;
	P_01_register register;
	// note: don't create the object outside the method  P_01_register register	= new P_01_register(driver);

	public void Initialize() 
	{
		  register = new P_01_register(driver);
	}
	
  @Test
  public void Register_Valid_User() throws IOException, InterruptedException {
	  Initialize();
	 register.El_00_registerLink().click();
	 register.El_01_genderMale().click();
	 register.El_02_FirstName().sendKeys(Proper.getPropertydata("FirstName"));
	 register.El_03_LastName().sendKeys(Proper.getPropertydata("LastName"));
	 
	 select = new Select(register.El_04_DateOfBirthDay());
	 select.getOptions().get(new Random().nextInt(select.getOptions().size())).click();

	 select = new Select(register.El_04_DateOfBirthMonth());
	 select.getOptions().get(new Random().nextInt(select.getOptions().size())).click();

	 select = new Select(register.El_04_DateOfBirthYear());
	 select.getOptions().get(new Random().nextInt(select.getOptions().size())).click();
	  
	 register.El_05_Email().sendKeys(Proper.getPropertydata("Email"));
	 register.El_06_Password().sendKeys(Proper.getPropertydata("Password"));
	  register.El_06_ConfirmPassword().sendKeys(Proper.getPropertydata("Password"));
	  register.El_07_registerBtn().click();
	  
	  if(!register.El_09_existMsg().isEmpty())
		{
	  assertTrue(register.El_09_existMsg().get(0).isDisplayed(), "Email is already exist");
		}
	  else
		{
	  assertTrue(register.El_08_successMsg().get(0).isDisplayed(), "Your registration completed");
		}
	
  }
}
