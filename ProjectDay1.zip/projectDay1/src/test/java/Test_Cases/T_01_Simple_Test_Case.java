package Test_Cases;

import org.testng.annotations.Test;


import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.Test;

import javafx.beans.property.SetProperty;
import org.testng.TestNGException;


@Test
public class T_01_Simple_Test_Case extends T_0_TestBase {


	public void GetBrowserAndUrl () throws IOException {
		System.out.println(prop.getProperty("BaseURL"));
		System.out.println(prop.getProperty("browserName"));

	}





}
