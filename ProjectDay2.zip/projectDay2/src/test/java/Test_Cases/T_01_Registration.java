package Test_Cases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import Pages.P_1_Registration;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.Driver;
import java.util.Random;

import org.testng.annotations.Test;

import javafx.beans.property.SetProperty;

import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.TestNGException;
import static org.testng.Assert.assertFalse;


public class T_01_Registration extends T_0_TestBase {

	@Test
	public void Registration () throws IOException,InterruptedException  {
		P_1_Registration p01 = new P_1_Registration(driver);
		p01.Reg_Btn().click();
		Thread.sleep(2000);
		p01.Gender_Btn().click();
		p01.FirstName().sendKeys(prop.getProperty("FirstName"));

		p01.Last_Name().sendKeys(prop.getProperty("LastName"));
		
		Select D = new Select(p01.Birth_Date());
		D.getOptions().get(new Random().nextInt(D.getOptions().size())).click();

		Select M = new Select(p01.Birth_Month());
		M.getOptions().get(new Random().nextInt(M.getOptions().size())).click();

		Select Y = new Select(p01.Birth_Year());
		Y.getOptions().get(new Random().nextInt(Y.getOptions().size())).click();
		
		p01.Email().sendKeys(prop.getProperty("Email"));

		p01.Password().sendKeys(prop.getProperty("Password"));

		p01.confirm_password().sendKeys(prop.getProperty("Confirm_Password"));

		p01.Complete_Reg_Btn().click();

		if (p01.Error_Msg().isEmpty()){
			assertFalse(p01.Success_Msg().isEmpty(), "Your registration completed");
			}
	}

}




