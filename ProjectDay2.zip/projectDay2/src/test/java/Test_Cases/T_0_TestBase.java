package Test_Cases;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class T_0_TestBase {
	protected WebDriver driver;

	protected Properties prop = new Properties();

	public String getProperty(String KeyName) throws IOException
	{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.load(fis);
		return	prop.getProperty(KeyName);
	}

	public void setProperty(String KeyName, String Value) throws IOException
	{
		Properties prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.load(fis);
		prop.setProperty(KeyName, Value);
		FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.store(fos, "TestComment");
	}

	@BeforeTest
	public void beforeTest() throws IOException {
		if(getProperty("browserName").equals("chrome"))
		{
			String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", chromePath);
			driver = new ChromeDriver();
		}
		else if(getProperty("browserName").equals("firefox"))
		{
			String fireFoxPath = System.getProperty("user.dir") + "\\Drivers\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", fireFoxPath);
			driver = new FirefoxDriver(); 
		}
		driver.manage().window().maximize();
		driver.get("https://demo.nopcommerce.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@AfterMethod
	public void afterMethod() {
		driver.navigate().refresh();
	}

	//@AfterTest
	//public void afterTest() {
	//	driver.quit();
//	}
}
