package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.remote.RemoteTestNG;

public class P_0_PageBase {
	WebDriver driver;
	
	public P_0_PageBase(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
