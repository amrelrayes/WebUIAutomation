package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class P_1_Registration extends P_0_PageBase {

	public P_1_Registration (WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	public WebElement Reg_Btn(){
		return driver.findElement(By.xpath("//a[@class=\"ico-register\"]"));

	}

	public WebElement  Gender_Btn(){
		return driver.findElement(By.xpath("//label[@for=\"gender-male\"]"));
	}

	public WebElement FirstName(){
		return driver.findElement(By.xpath("//input[@name=\"FirstName\"]"));
	}

	public WebElement Last_Name(){
		return driver.findElement(By.xpath("//input[@name=\"LastName\"]"));
	}

	public WebElement Birth_Date(){
		return driver.findElement(By.xpath("//select[@name=\"DateOfBirthDay\"]"));
	}

	public WebElement Birth_Month(){
		return driver.findElement(By.xpath("//select[@name=\"DateOfBirthMonth\"]"));
	}

	public WebElement Birth_Year(){
		return driver.findElement(By.xpath("//select[@name=\"DateOfBirthYear\"]"));
	}

	public WebElement Email(){
		return driver.findElement(By.xpath("//input[@type=\"email\"and@id=\"Email\"]"));
	}

	public WebElement Password(){
		return driver.findElement(By.xpath("//input[@name=\"Password\"]"));
	}


	public WebElement confirm_password(){
		return driver.findElement(By.xpath("//input[@id=\"ConfirmPassword\"]"));
	}

	public WebElement Complete_Reg_Btn(){
		return driver.findElement(By.xpath("//input[@id=\"register-button\"]"));
	}
	
	public List<WebElement> Error_Msg(){
		return driver.findElements(By.xpath("//div[@class=\"message-error validation-summary-errors\"]"));
	}
	
	public List<WebElement> Success_Msg(){
		return driver.findElements(By.xpath("//div[@class=\"result\"]"));
	}

}

